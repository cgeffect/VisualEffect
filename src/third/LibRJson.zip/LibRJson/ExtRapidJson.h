//
// Created by Donkey Stone on 2019-10-08.
//

#ifndef SLIDEPLAYERSDK_RJSONUTIL_H
#define SLIDEPLAYERSDK_RJSONUTIL_H

#include <cstdlib>
#include <GxBasic/GxBasic.h>
#include <ExtLibs/LibRJson/RapidJson/writer.h>
#include <ExtLibs/LibRJson/RapidJson/document.h>
#include <ExtLibs/LibRJson/RapidJson/stringbuffer.h>

namespace ExtLib {
    
template<typename NameT>
inline GxBasic::GxVersion getVersionFromString(const rapidjson::Value &_val, const NameT &_name,
                                               const std::string _def = "0.0.0") {
    bool has = _val.HasMember(_name);
    GxBasic::GxVersion _out;
    if (has) {
        std::string tmp = _def;
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            tmp = _val[_name].GetString();
        }
        unsigned long len1 = tmp.find_first_of(".");
        unsigned long len2 = tmp.find_last_of(".");
        unsigned long size = tmp.size();
        int _ver_major = atoi(tmp.substr(0, len1).c_str());
        int _ver_minor = atoi(tmp.substr(len1 + 1, len2 - len1 - 1).c_str());
        int _ver_patch = atoi(tmp.substr(len2 + 1, size - len2 - 1).c_str());
        _out.setMajor(_ver_major);
        _out.setMinor(_ver_minor);
        _out.setPatch(_ver_patch);
    }
    return _out;
}


inline std::string rp_getString(const rapidjson::Value &_val, const std::string _def = "") {
    std::string _retVal = _def;
    rapidjson::Type _type = _val.GetType();
    if (_type == rapidjson::kStringType) {
        _retVal = _val.GetString();
    }
    return _retVal;
}

inline int rp_getInt(const rapidjson::Value &_val, const int _def = 0) {
    int _retVal = _def;
    rapidjson::Type _type = _val.GetType();
    if (_type == rapidjson::kStringType) {
        std::string tmp = _val.GetString();
        _retVal = atoi(tmp.c_str());
    } else if (_type == rapidjson::kNumberType) {
        _retVal = _val.GetInt();
    }
    return _retVal;
}

inline bool rp_getBool(const rapidjson::Value &_val, const bool _def = false) {
    bool _retVal = _def;
    rapidjson::Type _type = _val.GetType();
    if (_type == rapidjson::kStringType) {
        std::string tmp = _val.GetString();
        _retVal = (tmp.compare("true") == 0);
    } else {
        _retVal = _val.GetBool();
    }
    return _retVal;
}

inline float rp_getFloat(const rapidjson::Value &_val, const float _def = 0.f) {
    float _retVal = _def;
    rapidjson::Type _type = _val.GetType();
    if (_type == rapidjson::kStringType) {
        std::string tmp = _val.GetString();
        _retVal = (float) atof(tmp.c_str());
    } else if (_type == rapidjson::kNumberType) {
        _retVal = _val.GetFloat();
    }
    return _retVal;
}

inline double rp_getDouble(const rapidjson::Value &_val, const double _def = 0.0) {
    double _retVal = _def;
    rapidjson::Type _type = _val.GetType();
    if (_type == rapidjson::kStringType) {
        std::string tmp = _val.GetString();
        _retVal = atof(tmp.c_str());
    } else if (_type == rapidjson::kNumberType) {
        _retVal = _val.GetDouble();
    }
    return _retVal;
}

inline GxBasic::GxColor rp_getColor(const rapidjson::Value &_val, const GxBasic::GxColor _def = GxBasic::GxColor()) {
    if (!_val.IsArray())
        return GxBasic::GxColor();

    GxBasic::GxColor _retVal = _def;
    float _arr[4]{0};
    int i = 0;
    const auto _array = _val.GetArray();
    for (const auto &e : _array) {
        rapidjson::Type _type = e.GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = e.GetString();
            _arr[i] = atoi(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _arr[i] = e.GetFloat();
        }
        i++;
    }

    _retVal.r = _arr[0];
    _retVal.g = _arr[1];
    _retVal.b = _arr[2];
    _retVal.a = _arr[3];
    return _retVal;
}

inline GxBasic::GxVec2F rp_getVec2F(const rapidjson::Value &_val, const GxBasic::GxVec2F _def = GxBasic::GxVec2F()) {
    if (!_val.IsArray()) {
        return _def;
    }
    GxBasic::GxVec2F out = _def;
    int i = 0;
    float _arr[2]{0};
    const auto _array = _val.GetArray();
    for (const auto &e : _array) {
        if (i > 1) break;
        rapidjson::Type _type = e.GetType();
        if (_type == rapidjson::kNumberType) {
            _arr[i] = e.GetFloat();
        }
        i++;
    }
    out.set(_arr[0], _arr[1]);
    return out;
}

inline GxBasic::GxVec3F rp_getVec3F(const rapidjson::Value &_val, const GxBasic::GxVec3F _def = GxBasic::GxVec3F()) {
    if (!_val.IsArray()) {
        return _def;
    }
    GxBasic::GxVec3F out = _def;
    int i = 0;
    float _arr[3]{0};
    const auto _array = _val.GetArray();
    for (const auto &e : _array) {
        if (i > 2) break;
        rapidjson::Type _type = e.GetType();
        if (_type == rapidjson::kNumberType) {
            _arr[i] = e.GetFloat();
        }
        i++;
    }
    out.set(_arr[0], _arr[1], _arr[2]);
    return out;
}

inline GxBasic::GxVec4F rp_getVec4F(const rapidjson::Value &_val, const GxBasic::GxVec4F _def = GxBasic::GxVec4F()) {
    if (!_val.IsArray()) {
        return _def;
    }
    GxBasic::GxVec4F out = _def;
    int i = 0;
    float _arr[4]{0};
    const auto _array = _val.GetArray();
    for (const auto &e : _array) {
        if (i > 3) break;
        rapidjson::Type _type = e.GetType();
        if (_type == rapidjson::kNumberType) {
            _arr[i] = e.GetFloat();
        }
        i++;
    }
    out.set(_arr[0], _arr[1], _arr[2], _arr[3]);
    return out;
}

template<typename ValueT, typename NameT>
inline std::string rp_getSubString(const ValueT &_val, const NameT &_name, const std::string _def = "") {
    bool has = _val.HasMember(_name);
    std::string _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            _retVal = _val[_name].GetString();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline int rp_getSubInt(const ValueT &_val, const NameT &_name, const int _def = 0) {
    bool has = _val.HasMember(_name);
    int _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = atoi(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _retVal = _val[_name].GetInt();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline bool rp_getSubBool(const ValueT &_val, const NameT &_name, const bool _def = false) {
    bool has = _val.HasMember(_name);
    bool _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = (tmp.compare("true") == 0);
        } else if (_type == rapidjson::kNumberType) {
            int tmp = _val[_name].GetInt();
            _retVal = (tmp == 1);
        } else {
            _retVal = _val[_name].GetBool();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline float rp_getSubFloat(const ValueT &_val, const NameT &_name, const float _def = 0.f) {
    bool has = _val.HasMember(_name);
    float _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = (float) atof(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _retVal = _val[_name].GetFloat();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline double rp_getSubDouble(const ValueT &_val, const NameT &_name, const double _def = 0.0) {
    bool has = _val.HasMember(_name);
    double _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = atof(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _retVal = _val[_name].GetDouble();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline int64_t rp_getSubInt64(const ValueT &_val, const NameT &_name, const int64_t _def = 0) {
    bool has = _val.HasMember(_name);
    int64_t _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = atoll(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _retVal = _val[_name].GetInt64();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline uint64_t rp_getSubUint64(const ValueT &_val, const NameT &_name, const uint64_t _def = 0) {
    bool has = _val.HasMember(_name);
    uint64_t _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = _val[_name].GetString();
            _retVal = uint64_t(atoll(tmp.c_str()));
        } else if (_type == rapidjson::kNumberType) {
            _retVal = _val[_name].GetUint64();
        }
    }
    return _retVal;
}

template<typename ValueT, typename NameT>
inline GxBasic::GxColor rp_getSubColor(const ValueT &_val, const NameT &_name, const GxBasic::GxColor _def = GxBasic::GxColor()) {
    bool has = _val.HasMember(_name);
    if (!has) {
        return GxBasic::GxColor();
    }
    return rp_getColor(_val[_name]);
}

template<typename ValueT, typename NameT>
inline void rp_getSubVectorString(std::vector<std::string> &_v, const ValueT &_val, const NameT &_name, const int _def = 0) {
    bool has = _val.HasMember(_name);
    if (!has)
        return;
    const auto _array = _val[_name].GetArray();
    int size = _array.Size();
    if (size <= 0)
        return;
    for (const auto &e : _array) {
        std::string cur = e.GetString();
        _v.push_back(cur);
    }
};

template<typename ValueT, typename NameT>
inline GxBasic::GxVec2I rp_getSubVec2IFromString(const ValueT &_val, const NameT &_name, const std::string _def = "{0, 0}") {
    bool has = _val.HasMember(_name);
    GxBasic::GxVec2I _out(0, 0);
    std::string _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            _retVal = _val[_name].GetString();
        }
    }

    unsigned long lenM = _retVal.find_first_of(",");
    unsigned long lenA = _retVal.find_first_of("{");
    unsigned long lenB = _retVal.find_first_of("}");
    std::string num_a = _retVal.substr(lenA + 1, lenM - lenA - 1);
    std::string num_b = _retVal.substr(lenM + 1, lenB - lenM - 1);

    _out.x = atoi(num_a.c_str());
    _out.y = atoi(num_b.c_str());

    return _out;
};

template<typename ValueT, typename NameT>
inline GxBasic::GxVec2F rp_getSubVec2FFromString(const ValueT &_val, const NameT &_name, const std::string _def = "{0, 0}") {
    bool has = _val.HasMember(_name);
    GxBasic::GxVec2F _out(0, 0);
    std::string _retVal = _def;
    if (has) {
        rapidjson::Type _type = _val[_name].GetType();
        if (_type == rapidjson::kStringType) {
            _retVal = _val[_name].GetString();
        }
    }

    unsigned long lenM = _retVal.find_first_of(",");
    unsigned long lenA = _retVal.find_first_of("{");
    unsigned long lenB = _retVal.find_first_of("}");
    std::string num_a = _retVal.substr(lenA + 1, lenM - lenA - 1);
    std::string num_b = _retVal.substr(lenM + 1, lenB - lenM - 1);

    _out.x = (float) atof(num_a.c_str());
    _out.y = (float) atof(num_b.c_str());

    return _out;
};

template<typename ValueT, typename NameT>
inline GxBasic::GxArrFloat *rp_getSubArrayFloat(const ValueT &_val, const NameT &_name, const int _def = 0) {
    bool has = _val.HasMember(_name);
    if (!has)
        return nullptr;
    const auto _array = _val[_name].GetArray();
    int _size = _array.Size();
    if (_size <= 0)
        return nullptr;
    GxBasic::GxArrFloat *_arr = new GxBasic::GxArrFloat(_size);
    int i = 0;
    for (const auto &e : _array) {
        _arr->array[i] = e.GetFloat();
        i++;
    }
    return _arr;
};

template<typename ValueT, typename NameT>
inline GxBasic::GxArrInt *rp_getSubArrayInt(const ValueT &_val, const NameT &_name, const int _def = 0) {
    bool has = _val.HasMember(_name);
    if (!has)
        return nullptr;
    const auto _array = _val[_name].GetArray();
    int _size = _array.Size();
    if (_size <= 0)
        return nullptr;
    GxBasic::GxArrInt *_arr = new GxBasic::GxArrInt(_size);
    int i = 0;
    for (const auto &e : _array) {
        rapidjson::Type _type = e.GetType();
        if (_type == rapidjson::kStringType) {
            std::string tmp = e.GetString();
            _arr->array[i] = atoi(tmp.c_str());
        } else if (_type == rapidjson::kNumberType) {
            _arr->array[i] = e.GetInt();
        }
        i++;
    }
    return _arr;
};

template<typename ValueT, typename NameT>
inline GxBasic::GxArrVec2I *rp_getSubArrayFromStringVec2I(const ValueT &_val, const NameT &_name, const std::string _def = "{0, 0}") {
    bool has = _val.HasMember(_name);
    if (!has)
        return nullptr;
    std::string tmp = _def;

    const auto _array = _val[_name].GetArray();
    int _size = _array.Size();
    if (_size <= 0)
        return nullptr;
    GxBasic::GxArrVec2I *_out = new GxBasic::GxArrVec2I(_size);
    int i = 0;
    for (const auto &e : _array) {
        tmp = e.GetString();
        unsigned long lenM = tmp.find_first_of(",");
        unsigned long lenA = tmp.find_first_of("{");
        unsigned long lenB = tmp.find_first_of("}");
        std::string num_a = tmp.substr(lenA + 1, lenM - lenA - 1);
        std::string num_b = tmp.substr(lenM + 1, lenB - lenM - 1);
        _out->array[i].x = atoi(num_a.c_str());
        _out->array[i].y = atoi(num_b.c_str());
        i++;
    }
    return _out;
};

template<typename ValueT, typename NameT>
inline GxBasic::GxArrVec2F *rp_getSubArrayFromStringVec2F(const ValueT &_val, const NameT &_name, const std::string _def = "{0, 0}") {
    bool has = _val.HasMember(_name);
    if (!has)
        return nullptr;

    std::string tmp = _def;

    const auto _array = _val[_name].GetArray();
    int _size = _array.Size();
    if (_size <= 0)
        return nullptr;
    GxBasic::GxArrVec2F *_out = new GxBasic::GxArrVec2F(_size);
    int i = 0;
    for (const auto &e : _array) {
        tmp = e.GetString();
        unsigned long lenM = tmp.find_first_of(",");
        unsigned long lenA = tmp.find_first_of("{");
        unsigned long lenB = tmp.find_first_of("}");
        std::string num_a = tmp.substr(lenA + 1, lenM - lenA - 1);
        std::string num_b = tmp.substr(lenM + 1, lenB - lenM - 1);
        _out->array[i].x = (float) atof(num_a.c_str());
        _out->array[i].y = (float) atof(num_b.c_str());
        i++;
    }
    return _out;
};

}

#endif //SLIDEPLAYERSDK_RJSONUTIL_H
